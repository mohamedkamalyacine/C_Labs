#include <stdio.h>
#include <stdlib.h>

int main()
{
    char firstName[20] = {'\0'}, lastName[20] = {'\0'};

    printf("Enter first Name: ");
    scanf("%s", firstName);
    printf("Enter Last Name: ");
    scanf("%s", lastName);

    printf("Your Full name is %s %s\n", firstName, lastName);
    return 0;
}
